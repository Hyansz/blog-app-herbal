import jwt from "jsonwebtoken";
import { cookies } from "next/headers";

export async function getUserFromCookie() {
    try {
        const cookieStore = await cookies();

        const token = cookieStore.get("token")?.value;

        if (!token) {
            return null;
        }

        const user = jwt.verify(token, process.env.JWT_SECRET!) as {
            id: string;
            name: string;
            role: string;
        };

        return user;
    } catch {
        return null;
    }
}
