"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CreateCategoryPage() {
    const router = useRouter();

    const [name, setName] = useState("");

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();

        const res = await fetch("/api/categories", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                name,
            }),
        });

        if (res.ok) {
            router.push("/dashboard/categories");
            router.refresh();
        }
    }

    return (
        <main className="p-10">
            <div className="mx-auto max-w-2xl rounded-[32px] bg-white p-8 shadow-xl">
                <h1 className="mb-8 text-4xl font-bold text-[#1f4d2e]">
                    Tambah Kategori
                </h1>

                <form onSubmit={handleSubmit} className="space-y-5">
                    <input
                        type="text"
                        placeholder="Nama kategori"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full rounded-2xl border p-4"
                    />

                    <button className="rounded-2xl bg-[#1f4d2e] px-8 py-4 text-white">
                        Tambah
                    </button>
                </form>
            </div>
        </main>
    );
}
