import Link from "next/link";

async function getCategories() {
    const res = await fetch(`${process.env.NEXTAUTH_URL}/api/categories`, {
        cache: "no-store",
    });

    return res.json();
}

export default async function CategoriesPage() {
    const categories = await getCategories();

    return (
        <main className="p-10">
            <div className="mb-8 flex items-center justify-between">
                <div>
                    <h1 className="text-4xl font-bold text-[#1f4d2e]">
                        Kategori
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Kelola kategori herbal.
                    </p>
                </div>

                <Link
                    href="/dashboard/categories/create"
                    className="rounded-2xl bg-[#1f4d2e] px-6 py-3 font-semibold text-white"
                >
                    Tambah Kategori
                </Link>
            </div>

            <div className="overflow-hidden rounded-3xl border border-gray-200 bg-white">
                <table className="w-full">
                    <thead className="bg-[#f4f7f1]">
                        <tr>
                            <th className="px-6 py-5 text-left">Nama</th>

                            <th className="px-6 py-5 text-left">Slug</th>

                            <th className="px-6 py-5 text-right">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        {categories.map((item: any) => (
                            <tr key={item.id} className="border-t">
                                <td className="px-6 py-5">{item.name}</td>

                                <td className="px-6 py-5">{item.slug}</td>

                                <td className="px-6 py-5">
                                    <div className="flex justify-end gap-3">
                                        <Link
                                            href={`/dashboard/categories/edit/${item.id}`}
                                            className="rounded-xl bg-blue-500 px-4 py-2 text-sm text-white"
                                        >
                                            Edit
                                        </Link>

                                        <form
                                            action={`/api/categories/${item.id}`}
                                            method="POST"
                                        >
                                            <button
                                                formAction={`/api/categories/${item.id}`}
                                                className="rounded-xl bg-red-500 px-4 py-2 text-sm text-white"
                                            >
                                                Hapus
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </main>
    );
}
