"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AppLayout from "@/app/components/AppLayout";

export default function CreateArticlePage() {
    const router = useRouter();
    const [categories, setCategories] = useState<any[]>([]);
    const [uploading, setUploading] = useState(false);
    const [loading, setLoading] = useState(false);

    const [form, setForm] = useState({
        name: "",
        latinName: "",
        image: "",
        description: "",
        benefits: "",
        content: "",
        video1: "",
        video2: "",
        categoryId: "",
    });

    useEffect(() => {
        fetch("/api/categories")
            .then((res) => res.json())
            .then((data) => setCategories(data));
    }, []);

    async function uploadFile(file: File) {
        const formData = new FormData();

        formData.append("file", file);

        setUploading(true);

        const res = await fetch("/api/upload", {
            method: "POST",
            body: formData,
        });

        const data = await res.json();

        setUploading(false);

        return data.url;
    }

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();

        setLoading(true);

        const res = await fetch("/api/articles", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                ...form,
                authorId: "cmp16qi010000v6r8da5w9bv9",
            }),
        });

        setLoading(false);

        if (res.ok) {
            router.push("/dashboard/articles");
            router.refresh();
        }
    }

    return (
        <AppLayout
            search=""
            setSearch={() => {}}
            activeMenu="/dashboard/articles"
        >
            <main className="p-10">
                <div className="mx-auto max-w-4xl rounded-[32px] bg-white p-8 shadow-xl">
                    <h1 className="mb-8 text-4xl font-bold text-[#1f4d2e]">
                        Tambah Artikel
                    </h1>

                    <form onSubmit={handleSubmit} className="space-y-5">
                        <input
                            type="text"
                            placeholder="Nama Artikel"
                            value={form.name}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    name: e.target.value,
                                })
                            }
                            className="w-full rounded-2xl border p-4"
                        />

                        <input
                            type="text"
                            placeholder="Nama Latin"
                            value={form.latinName}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    latinName: e.target.value,
                                })
                            }
                            className="w-full rounded-2xl border p-4"
                        />

                        <select
                            value={form.categoryId}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    categoryId: e.target.value,
                                })
                            }
                            className="w-full rounded-2xl border p-4"
                        >
                            <option value="">Pilih kategori</option>

                            {categories.map((category) => (
                                <option key={category.id} value={category.id}>
                                    {category.name}
                                </option>
                            ))}
                        </select>

                        <div>
                            <label className="mb-2 block font-medium">
                                Upload Gambar
                            </label>

                            <input
                                type="file"
                                accept="image/*"
                                onChange={async (e) => {
                                    const file = e.target.files?.[0];

                                    if (!file) return;

                                    const url = await uploadFile(file);

                                    setForm({
                                        ...form,
                                        image: url,
                                    });
                                }}
                            />

                            {uploading && (
                                <p className="mt-2 text-sm text-gray-500">
                                    Uploading...
                                </p>
                            )}

                            {form.image && (
                                <img
                                    src={form.image}
                                    className="mt-4 h-52 w-full rounded-2xl object-cover"
                                />
                            )}
                        </div>

                        <textarea
                            placeholder="Description"
                            value={form.description}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    description: e.target.value,
                                })
                            }
                            className="h-32 w-full rounded-2xl border p-4"
                        />

                        <textarea
                            placeholder="Benefits"
                            value={form.benefits}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    benefits: e.target.value,
                                })
                            }
                            className="h-32 w-full rounded-2xl border p-4"
                        />

                        <textarea
                            placeholder="Content"
                            value={form.content}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    content: e.target.value,
                                })
                            }
                            className="h-40 w-full rounded-2xl border p-4"
                        />

                        <div>
                            <label className="mb-2 block font-medium">
                                Upload Video 1
                            </label>

                            <input
                                type="file"
                                accept="video/*"
                                onChange={async (e) => {
                                    const file = e.target.files?.[0];

                                    if (!file) return;

                                    const url = await uploadFile(file);

                                    setForm({
                                        ...form,
                                        video1: url,
                                    });
                                }}
                            />

                            {form.video1 && (
                                <video
                                    controls
                                    className="mt-4 w-full rounded-2xl"
                                >
                                    <source src={form.video1} />
                                </video>
                            )}
                        </div>

                        <div>
                            <label className="mb-2 block font-medium">
                                Upload Video 2
                            </label>

                            <input
                                type="file"
                                accept="video/*"
                                onChange={async (e) => {
                                    const file = e.target.files?.[0];

                                    if (!file) return;

                                    const url = await uploadFile(file);

                                    setForm({
                                        ...form,
                                        video2: url,
                                    });
                                }}
                            />

                            {form.video2 && (
                                <video
                                    controls
                                    className="mt-4 w-full rounded-2xl"
                                >
                                    <source src={form.video2} />
                                </video>
                            )}
                        </div>

                        <button className="rounded-2xl bg-[#1f4d2e] px-8 py-4 font-semibold text-white">
                            {loading ? "Loading..." : "Tambah Artikel"}
                        </button>
                    </form>
                </div>
            </main>
        </AppLayout>
    );
}
