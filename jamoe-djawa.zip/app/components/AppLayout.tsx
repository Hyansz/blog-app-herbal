"use client";

import dynamic from "next/dynamic";
import { ReactNode, useEffect, useState } from "react";

import Footer from "./Footer";
import Header from "./Header";
import Sidebar from "./Sidebar";

const LoginModal = dynamic(() => import("./LoginModal"), {
    ssr: false,
});

const RegisterModal = dynamic(() => import("./RegisterModal"), {
    ssr: false,
});

interface AppLayoutProps {
    children: ReactNode;

    search?: string;
    setSearch?: (value: string) => void;

    backHref?: string;
    backLabel?: string;

    activeMenu?: string;
}

interface UserType {
    name: string;
    role: string;
}

export default function AppLayout({
    children,
    search,
    setSearch,
    backHref,
    backLabel,
    activeMenu,
}: AppLayoutProps) {
    const [user, setUser] = useState<UserType | null>(null);

    const [showLogin, setShowLogin] = useState(false);
    const [showRegister, setShowRegister] = useState(false);

    useEffect(() => {
        let mounted = true;

        async function getUser() {
            try {
                const res = await fetch("/api/auth/me", {
                    cache: "force-cache",
                });

                if (!res.ok) return;

                const data = await res.json();

                if (mounted) {
                    setUser(data);
                }
            } catch {}
        }

        getUser();

        return () => {
            mounted = false;
        };
    }, []);

    return (
        <>
            <main className="min-h-screen bg-[#f4f7f1]">
                <div className="flex min-h-screen">
                    <Sidebar activeMenu={activeMenu} user={user} />

                    <div className="flex min-w-0 flex-1 flex-col">
                        <Header
                            search={search}
                            setSearch={setSearch}
                            backHref={backHref}
                            backLabel={backLabel}
                            user={user}
                            onOpenLogin={() => setShowLogin(true)}
                        />

                        <section className="flex-1 p-5 lg:p-8">
                            <div className="mx-auto max-w-7xl">{children}</div>
                        </section>

                        <Footer />
                    </div>
                </div>
            </main>

            {showLogin && (
                <LoginModal
                    onClose={() => setShowLogin(false)}
                    onOpenRegister={() => {
                        setShowLogin(false);
                        setShowRegister(true);
                    }}
                />
            )}

            {showRegister && (
                <RegisterModal
                    onClose={() => setShowRegister(false)}
                    onOpenLogin={() => {
                        setShowRegister(false);
                        setShowLogin(true);
                    }}
                />
            )}
        </>
    );
}
