"use client";

import Link from "next/link";
import { memo, useCallback } from "react";
import { FaUserCircle } from "react-icons/fa";
import { FiLogOut } from "react-icons/fi";

import SearchBar from "./SearchBar";

interface HeaderProps {
    search?: string;
    setSearch?: (value: string) => void;

    backHref?: string;
    backLabel?: string;

    onOpenLogin?: () => void;

    user?: {
        name: string;
        role: string;
    } | null;
}

function HeaderComponent({
    search,
    setSearch,
    backHref,
    backLabel = "Kembali",
    user,
    onOpenLogin,
}: HeaderProps) {
    const isBackMode = !!backHref;

    const handleLogout = useCallback(async () => {
        await fetch("/api/auth/logout", {
            method: "POST",
        });

        window.location.reload();
    }, []);

    return (
        <header className="sticky top-0 z-50 border-b border-[#dce6dc]/70 bg-white/80 backdrop-blur-xl">
            <div className="flex items-center justify-between gap-5 px-8 py-5">
                <div className="w-full max-w-2xl">
                    {isBackMode ? (
                        <Link
                            href={backHref}
                            prefetch
                            className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#1f4d2e] to-[#2f6b3f] px-6 py-4 font-medium text-white shadow-lg transition-all duration-300 hover:-translate-y-0.5"
                        >
                            ← {backLabel}
                        </Link>
                    ) : (
                        <SearchBar value={search || ""} onChange={setSearch!} />
                    )}
                </div>

                <div className="hidden shrink-0 items-center gap-5 md:flex">
                    <div className="flex items-center gap-3">
                        <div className="h-3 w-3 rounded-full bg-[#7dbb43]" />

                        <p className="text-sm font-medium tracking-wide text-[#5f6f61]">
                            HerbalPedia Indonesia
                        </p>
                    </div>

                    {user ? (
                        <div className="flex items-center gap-3">
                            <div className="flex h-14 items-center gap-3 rounded-2xl border border-[#dce6dc] bg-white px-4 shadow-sm">
                                <div className="text-right leading-tight">
                                    <p className="text-sm font-bold text-[#1f4d2e]">
                                        {user.name}
                                    </p>

                                    <p className="text-xs capitalize text-[#5f6f61]">
                                        {user.role}
                                    </p>
                                </div>

                                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#eef6ec]">
                                    <FaUserCircle className="text-[24px] text-[#4d8b5e]" />
                                </div>
                            </div>

                            <button
                                onClick={handleLogout}
                                className="flex h-14 w-14 items-center justify-center rounded-2xl border border-[#f1d0d0] bg-white text-[#b63b3b] shadow-sm transition-all duration-300 hover:bg-[#fff5f5]"
                            >
                                <FiLogOut className="text-[20px]" />
                            </button>
                        </div>
                    ) : (
                        <button
                            onClick={onOpenLogin}
                            className="flex items-center gap-3 rounded-2xl border border-[#dce6dc] bg-white px-4 py-2 shadow-sm transition-all duration-300 hover:border-[#7dbb43]"
                        >
                            <div>
                                <p className="text-sm font-bold text-[#1f4d2e]">
                                    Login
                                </p>

                                <p className="text-xs text-[#5f6f61]">
                                    Masuk akun
                                </p>
                            </div>

                            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#eef6ec]">
                                <FaUserCircle className="text-3xl text-[#4d8b5e]" />
                            </div>
                        </button>
                    )}
                </div>
            </div>
        </header>
    );
}

export default memo(HeaderComponent);
