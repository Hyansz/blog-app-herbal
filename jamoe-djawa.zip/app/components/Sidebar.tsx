"use client";

import Link from "next/link";
import { memo, useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { FiChevronDown } from "react-icons/fi";

const menus = [
    { name: "Beranda", href: "/" },
    { name: "Rimpang", href: "/rimpang" },
    { name: "Rempah", href: "/rempah" },
    { name: "Daun", href: "/daun" },
    { name: "Penyakit", href: "/penyakit" },
    { name: "Informasi", href: "/informasi" },
    { name: "Tips Sehat", href: "/tips-sehat" },
];

const adminMenus = [
    {
        name: "Kelola Artikel",
        href: "/dashboard/articles",
    },
    {
        name: "Kelola Kategori",
        href: "/dashboard/categories",
    },
];

interface SidebarProps {
    activeMenu?: string;

    user?: {
        name: string;
        role: string;
    } | null;
}

function SidebarComponent({ activeMenu, user }: SidebarProps) {
    const pathname = usePathname();

    const [openMenu, setOpenMenu] = useState(true);
    const [openAdminMenu, setOpenAdminMenu] = useState(true);

    useEffect(() => {
        const menuState = localStorage.getItem("sidebar-menu");
        const adminState = localStorage.getItem("sidebar-admin");

        if (menuState) {
            setOpenMenu(menuState === "true");
        }

        if (adminState) {
            setOpenAdminMenu(adminState === "true");
        }
    }, []);

    function toggleMenu() {
        const newState = !openMenu;

        setOpenMenu(newState);

        localStorage.setItem("sidebar-menu", String(newState));
    }

    function toggleAdminMenu() {
        const newState = !openAdminMenu;

        setOpenAdminMenu(newState);

        localStorage.setItem("sidebar-admin", String(newState));
    }

    return (
        <aside className="sticky top-0 hidden h-screen w-[290px] overflow-y-auto border-r border-[#31543d] bg-gradient-to-b from-[#16361f] via-[#183c24] to-[#102817] text-white lg:block">
            <div className="flex min-h-full flex-col justify-between p-5">
                <div>
                    <div className="mb-8 rounded-[30px] border border-white/20 bg-gradient-to-br from-[#f7f9f4] to-[#dff0d2] p-5">
                        <img
                            src="/logo-jd.png"
                            alt="Jamoe Djawa"
                            className="w-full object-contain"
                            loading="lazy"
                        />
                    </div>

                    {user?.role === "ADMIN" && (
                        <div className="mb-6">
                            <button
                                onClick={toggleAdminMenu}
                                className="mb-4 flex w-full items-center justify-between rounded-2xl bg-white/5 px-4 py-4"
                            >
                                <p className="text-xs font-bold uppercase tracking-[0.3em] text-[#7fa08a]">
                                    Admin Menu
                                </p>

                                <FiChevronDown
                                    className={`transition-transform duration-300 ${
                                        openAdminMenu ? "rotate-180" : ""
                                    }`}
                                />
                            </button>

                            {openAdminMenu && (
                                <nav className="flex flex-col gap-2">
                                    {adminMenus.map((menu) => {
                                        const isActive = pathname.startsWith(
                                            menu.href,
                                        );

                                        return (
                                            <Link
                                                key={menu.href}
                                                href={menu.href}
                                                prefetch
                                                className={`rounded-2xl px-4 py-4 text-[15px] font-medium transition-all ${
                                                    isActive
                                                        ? "bg-[#7dbb43] text-[#183c24]"
                                                        : "text-[#dce6dc] hover:bg-[#245434]"
                                                }`}
                                            >
                                                {menu.name}
                                            </Link>
                                        );
                                    })}
                                </nav>
                            )}
                        </div>
                    )}

                    <button
                        onClick={toggleMenu}
                        className="mb-4 flex w-full items-center justify-between rounded-2xl bg-white/5 px-4 py-4"
                    >
                        <p className="text-xs font-bold uppercase tracking-[0.3em] text-[#7fa08a]">
                            Main Menu
                        </p>

                        <FiChevronDown
                            className={`transition-transform duration-300 ${
                                openMenu ? "rotate-180" : ""
                            }`}
                        />
                    </button>

                    {openMenu && (
                        <nav className="flex flex-col gap-2">
                            {menus.map((menu) => {
                                const isActive =
                                    pathname === menu.href ||
                                    activeMenu === menu.href;

                                return (
                                    <Link
                                        key={menu.href}
                                        href={menu.href}
                                        prefetch
                                        className={`rounded-2xl px-4 py-4 text-[15px] font-medium transition-all ${
                                            isActive
                                                ? "bg-[#7dbb43] text-[#183c24]"
                                                : "text-[#dce6dc] hover:bg-[#245434]"
                                        }`}
                                    >
                                        {menu.name}
                                    </Link>
                                );
                            })}
                        </nav>
                    )}
                </div>

                <div className="rounded-[30px] bg-[#245434] p-6">
                    <h3 className="text-lg font-bold text-[#dff0d2]">
                        Herbal Alami
                    </h3>

                    <p className="mt-2 text-sm text-[#b9d9a8]">
                        Edukasi tanaman herbal tradisional Indonesia.
                    </p>
                </div>
            </div>
        </aside>
    );
}

export default memo(SidebarComponent);
