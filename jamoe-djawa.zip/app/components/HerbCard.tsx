import Link from "next/link";
import Image from "next/image";

interface Props {
    herb: {
        name: string;
        slug: string;
        image: string;
    };
}

export default function HerbCard({ herb }: Props) {
    return (
        <Link href={`/herbal/${herb.slug}`} prefetch>
            <article className="group overflow-hidden rounded-[32px] border border-[#dce6dc] bg-white shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-[#7dbb43]">
                <div className="relative h-56 overflow-hidden bg-[#eef2ea]">
                    <Image
                        src={herb.image}
                        alt={herb.name}
                        fill
                        sizes="(max-width:768px) 100vw, 33vw"
                        className="object-cover transition duration-500 group-hover:scale-105"
                    />

                    <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
                </div>

                <div className="p-6">
                    <p className="mb-2 text-center text-xs font-semibold uppercase tracking-[0.25em] text-[#7dbb43]">
                        Herbal Nusantara
                    </p>

                    <h2 className="text-center text-2xl font-bold text-[#1f4d2e]">
                        {herb.name}
                    </h2>
                </div>
            </article>
        </Link>
    );
}
